<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD profile="http://gmpg.org/xfn/1">
</HEAD>
<BODY>
Unexpected FATAL database error.<br>
Details stored in database with reference #<?= $_GET['db_error_id'] ?>.
</BODY>
</HTML>
