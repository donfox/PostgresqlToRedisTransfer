<?php

class ca_province {

    static public $options = array(
        'ON' => 'Ontario',
        'QC' => 'Quebec',
        'NS' => 'Nova Scotia',
        'NB' => 'New Brunswick',
        'MB' => 'Manitoba',
        'BC' => 'British Columbia',
        'PE' => 'Prince Edward Island',
        'SK' => 'Saskatchewan',
        'AB' => 'Alberta',
        'NL' => 'Newfoundland and Labrador',
        'NT' => 'Northwest Territories',
        'YT' => 'Yukon Territory',
        'NU' => 'Nunavut'
        );

}

?>
