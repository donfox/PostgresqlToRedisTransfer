SET client_min_messages TO WARNING;
CREATE LANGUAGE plpgsql;
\i session.sql
\i address.sql
\i community.sql
\i person.sql
\i member.sql
\i member_health.sql
\i event.sql
\i event_type.sql

\i us.sql
\i ca.sql
\i gb.sql
