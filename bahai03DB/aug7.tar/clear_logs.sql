truncate app_session;
truncate change_log;
truncate db_error_log;
truncate edit_error;
truncate edit_errors_group;
