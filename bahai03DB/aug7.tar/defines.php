<?php
// $Id: defines.php,v 1.1 2006/04/03 05:13:08 bmartin Exp $

define('KEY_SEPARATOR', "|");
define('BAHAI', "Bah&aacute;'&iacute;"); 
define('BAHAI_UC', "BAH&Aacute;'&Iacute;"); 
define('SQL_LOG', "../SQL_LOG");

?>
